export const NotFound = () => {
    return <>Not Found</>
}