export const Header = () => {
    return (
        <header>
            <h1>MyReads</h1>
        </header>
    );
}